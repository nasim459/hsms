<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FrontEndController extends Controller
{
    public function index(){

        
        $menu = view('fe.pages.menu');
        $slider= view('fe.pages.slider');
        $content=view('fe.pages.content');
        return view('fe.master_fe')
                    ->with('menu',$menu)
                    ->with('slider',$slider)
                    ->with('maincontent', $content);


        return view('fe.index');

    }
}
