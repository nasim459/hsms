@section('broadcasting_content')
<!-- begin section-container -->
<div class="section-container">
    <!-- begin row -->
    <div class="row">
        <!-- begin col-12 -->
        <div class="col-md-12">

            <!-- begin #content -->
            <div id="content" class="">
                <!-- begin mail-box -->
                <div class="mail-box">
                    <!-- begin mail-box-sidebar -->
                    <div class="mail-box-sidebar dropdown">
                        <!-- begin mail-box-mobile-toggler -->
                        <div class="mail-box-mobile-toggler">
                            <a href="#" class="btn btn-default width-100 btn-sm" data-toggle="email-sidebar">Inbox <b class="caret"></b></a>
                        </div>
                        <!-- end mail-box-mobile-toggler -->
                        <!-- begin email-sidebar -->
                        <div class="dropdown-menu email-sidebar" id="email-sidebar" data-scrollbar="true" data-height="100%">
                            <!-- begin mail-box-header -->
                            <div class="mail-box-header text-center">
                                <a href="email_compose.html" class="btn btn-danger width-150 btn-sm">
                                    COMPOSE
                                </a>
                            </div>
                            <!-- end mail-box-header -->
                            <!-- begin mail-box-wrapper -->
                            <div class="mail-box-wrapper">
                                <h4 class="title m-t-0">FOLDER</h4>
                                <ul class="mail-box-menu">
                                    <li class="active"><a href="email_inbox.html">Inbox <b>(5)</b></a></li>
                                    <li><a href="email_inbox.html">Archive</a></li>
                                    <li><a href="email_inbox.html">Junk</a></li>
                                    <li><a href="email_inbox.html">Drafts</a></li>
                                    <li><a href="email_inbox.html">Sent</a></li>
                                    <li><a href="email_inbox.html">Trash <b>(99+)</b></a></li>
                                    <li><a href="email_inbox.html">Flagged</a></li>
                                </ul>
                                <h4 class="title">CONTACT</h4>
                                <ul class="mail-box-user-list">
                                    <li><a href="#"><img src="assets/img/user_1.jpg" alt="" /> <i class="fa fa-circle text-success-light"></i> Finlay Josep</a></li>
                                    <li><a href="#"><img src="assets/img/user_2.jpg" alt="" /> <i class="fa fa-circle text-inverse"></i> Lucas Enosh</a></li>
                                    <li><a href="#"><img src="assets/img/user_3.jpg" alt="" /> <i class="fa fa-circle text-inverse"></i> Balthazar Swarna</a></li>
                                    <li><a href="#"><img src="assets/img/user_4.jpg" alt="" /> <i class="fa fa-circle text-warning-light"></i> Stribog Taliesin</a></li>
                                    <li><a href="#"><img src="assets/img/user_5.jpg" alt="" /> <i class="fa fa-circle text-danger-light"></i> Juan Philemon</a></li>
                                </ul>
                            </div>
                            <!-- end mail-box-wrapper -->
                        </div>
                        <!-- end email-sidebar -->
                    </div>
                    <!-- end mail-box-sidebar -->
                    <!-- begin mail-box-content -->
                    <div class="mail-box-content">
                        <!-- begin mail-box-toolbar -->
                        <div class="mail-box-toolbar">
                            <div class="pull-left">
                                <a href="#" class="btn btn-white btn-sm m-r-5"><i class="fa fa-reply"></i> <span class="hidden-xs">Reply</span></a>
                                <a href="#" class="btn btn-white btn-sm m-r-5"><i class="fa fa-reply-all"></i> <span class="hidden-xs">Reply All</span></a>
                                <a href="#" class="btn btn-white btn-sm m-r-5"><i class="fa fa-share"></i> <span class="hidden-xs">Forward</span></a>
                                <a href="#" class="btn btn-white btn-sm"><i class="fa fa-trash"></i> <span class="hidden-xs">Delete</span></a>
                            </div>
                            <div class="pull-right">
                                <span class="btn-group">
                                    <a href="#" class="btn btn-white btn-sm"><i class="fa fa-chevron-up"></i></a>
                                    <a href="#" class="btn btn-white btn-sm"><i class="fa fa-chevron-down"></i></a>
                                </span>
                                <a href="email_inbox.html" class="btn btn-white btn-sm m-l-5"><i class="fa fa-remove"></i></a>
                            </div>
                        </div>
                        <!-- end mail-box-toolbar -->
                        <!-- begin mail-box-container -->
                        <div class="mail-box-container">
                            <!-- begin scrollbar -->
                            <div data-scrollbar="true" data-height="100%">
                                <!-- begin mail-detail -->
                                <div class="mail-detail">
                                    <!-- begin mail-detail-header -->
                                    <div class="mail-detail-header">
                                        <h4 class="mail-subject">Your order #19043902 is being processed!‏</h4>
                                    </div>
                                    <!-- end mail-detail-header -->
                                    <!-- begin mail-detail-info -->
                                    <div class="mail-detail-info">
                                        <ul class="media-list m-b-0">
                                            <li class="media">
                                                <a href="javascript:;" class="pull-left">
                                                    <img src="assets/img/user_1.jpg" alt="" class="media-object" />
                                                </a>
                                                <div class="media-body">
                                                    <div class="email-from">
                                                        <span class="email-sender">Twitter, Inc</span> 
                                                        <span class="email-date">11/12/2015</span>
                                                    </div>
                                                    <div class="email-to">
                                                        <small class="text-muted m-r-5">to</small> seantheme@live.co.uk, charlie@gmail.com, danijel@hotmail.com
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <!-- end mail-detail-info -->
                                    <!-- begin mail-detail-attachment -->
                                    <div class="mail-detail-attachment clearfix">
                                        <div class="mail-attachment">
                                            <a href="#">
                                                <div class="document-file">
                                                    <i class="fa fa-file-pdf-o"></i>
                                                </div>
                                                <div class="document-name">invoice.pdf</div>
                                            </a>
                                        </div>
                                        <div class="mail-attachment">
                                            <a href="#">
                                                <div class="document-file">
                                                    <i class="fa fa-film"></i>
                                                </div>
                                                <div class="document-name">video.mp4</div>
                                            </a>
                                        </div>
                                        <div class="mail-attachment">
                                            <a href="#">
                                                <div class="document-file">
                                                    <img src="assets/img/media-1.jpg" alt="">
                                                </div>
                                                <div class="document-name">image.jpg</div>
                                            </a>
                                        </div>
                                        <a href="#">Download as zip</a>
                                    </div>
                                    <!-- end mail-detail-attachment -->
                                    <!-- begin mail-detail-body -->
                                    <div class="mail-detail-body">
                                        Hi Dear Customer,<br />
                                        <br />
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras vel auctor nisi, vel auctor orci. <br />
                                        Aenean in pretium odio, ut lacinia tellus. Nam sed sem ac enim porttitor vestibulum vitae at erat.<br />
                                        <br />
                                        Curabitur auctor non orci a molestie. Nunc non justo quis orci viverra pretium id ut est. <br />
                                        Nullam vitae dolor id enim consequat fermentum. Ut vel nibh tellus. <br />
                                        Duis finibus ante et augue fringilla, vitae scelerisque tortor pretium. <br />
                                        Phasellus quis eros erat. Nam sed justo libero.<br />
                                        <br />
                                        Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.<br />
                                        Sed tempus dapibus libero ac commodo.<br />
                                        <br />
                                        <br />
                                        Regards,<br />
                                        Twitter Inc,<br />
                                        795 Folsom Ave, Suite 600<br />
                                        San Francisco, CA 94107<br />
                                        P: (123) 456-7890<br />
                                    </div>
                                    <!-- end mail-detail-body -->
                                </div>
                                <!-- end mail-detail -->
                            </div>
                            <!-- end scrollbar -->
                        </div>
                        <!-- end mail-box-container -->
                    </div>
                    <!-- end mail-box-content -->
                </div>
                <!-- end mail-box -->
            </div>
            <!-- end #content -->

        </div>
        <!-- end col-12 -->
    </div>
    <!-- end row -->
</div>
<!-- end section-container -->
@endsection