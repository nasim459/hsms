<!doctype html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
</head>
<body>
<p>
    Dear user, Welcome to our website.
</p>

<div>

    Activate your account by clicking on the following link.<br /> <br />
    {{ $link }} <br /><br />


    Your Login Email: {{ $email }} <br />
    Password: {{ $password }}<br /><br />


    Welcome once again. mr <br /><br />

</div>
</body>
</html>