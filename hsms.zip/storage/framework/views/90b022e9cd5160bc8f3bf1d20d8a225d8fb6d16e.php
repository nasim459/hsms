<?php $__env->startSection('maincontent'); ?>
<!-- begin breadcrumb -->
<ol class="breadcrumb pull-right">
    <li><a href="<?php echo e(URL::to('dboard')); ?>" title="Go Dahsboard">Dashboard</a></li>
    <li class="active">Broadcasting</li>
</ol>
<ol class="breadcrumb pull-left">
    <li><a href="<?php echo e(URL::to('dboard')); ?>" class="btn btn-sm btn-white" title="Go Dahsboard"><i class="fa fa-home"></i></a></li>
</ol>
<!-- end breadcrumb -->

<!-- begin section-container -->
<div class="section-container">
    <!-- begin row -->
    <div class="row">
        <!-- begin col-12 -->
        <div class="col-md-12">
            <!-- begin menu bar -->
            <p class="text-center  m-b-mi-23">
                <a href="<?php echo e(URL::to('inventory-ataglance')); ?>" class="btn btn-default widtg115">At A Glance</a>
                <a href="<?php echo e(URL::to('inventory-income')); ?>" class="btn btn-default widtg115">Income</a>
                <a href="<?php echo e(URL::to('inventory-utilities')); ?>" class="btn btn-default widtg115">Utilities Bills</a>
            </p>
            <!-- end menu bar -->
        </div>
    </div>
    <!-- end row -->
</div>
<?php echo $__env->yieldContent('inventory_content'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master_ap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>