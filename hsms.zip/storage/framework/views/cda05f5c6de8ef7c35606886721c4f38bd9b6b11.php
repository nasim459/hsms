<?php $__env->startSection('people_content'); ?>
<!-- begin section-container -->
<div class="section-container">
    <!-- begin panel -->
    <div class="panel without-pagination clearfix m-b-0">
        <table id="data-table" class="table table-bordered table-hover">
            <thead>
                <tr class="success">
                    <th>Picture &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ID</th>
                    <th><span class="m-l-20">Name  &nbsp; &nbsp;</span></th>
                    <th>Position</th>
                    <th>Mobile Number</th>
                    <th>E-Mail Address</th>
                    <th>Payment</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $number = 0; ?>
                <?php $__currentLoopData = $emp_show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> 
                <tr>
                    <td>
                        <!--<img src="<?php echo e(URL::asset('ap/assets/img/user_profile.jpg')); ?>" class="img-h-w" alt="" />-->
                        <?php if($v->emp_image != NULL): ?>
                        <img src="<?php echo e(URL::asset($v->emp_image)); ?>" class="img-h-w" alt="" />
                        <?php else: ?>
                        <img src="<?php echo e(URL::asset('ap/assets/img_blank/img_blank.jpg')); ?>" class="img-h-w" alt="" />
                        <?php endif; ?>
                        
                        <b>&nbsp;<?php echo e($v->emp_id_no); ?></b>
                    </td>
                    <td><?php echo e($v->emp_name); ?></td>
                    <td class="text-center"><b><?php echo e($v->emp_position); ?></b></td>
                    <td><?php echo e($v->emp_phone1); ?></td>
                    <td><?php echo e($v->emp_email); ?></td>
                    <td class="text-center"><a href="" class="btn btn-default btn-xs">Paid</a> </td>
                    <td><a href="<?php echo e(URL::to('info-emp-details/'.$v->emp_details_id)); ?>" class="btn btn-default btn-xs"><i class="fa fa-list-alt"></i> Details</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
    </div>
    <!-- end panel -->
</div>
<!-- end section-container -->
<?php $__env->stopSection(); ?>