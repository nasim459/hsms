<!doctype html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
</head>
<body>
<p>
    Dear user, Welcome to our website.
</p>

<div>

    Activate your account by clicking on the following link.<br /> <br />
    <?php echo e($link); ?> <br /><br />


    Your Login Email: <?php echo e($email); ?> <br />
    Password: <?php echo e($password); ?><br /><br />


    Welcome once again.<br /><br />

</div>
</body>
</html>