<?php $__env->startSection('people_content'); ?>
<!-- begin section-container -->
<div class="section-container">
    <!-- begin panel -->
    <div class="panel without-pagination clearfix m-b-0">
        <table id="data-table" class="table table-bordered table-hover">
            <thead>
                <tr class="success">
                    <th>Picture &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ID</th>
                    <th><span class="m-l-20">Name  &nbsp; &nbsp;</span></th>
                    <th>Building - Floor - Unit</th>
                    <th>Mobile Number</th>
                    <th>E-Mail Address</th>
                    <th>Payment</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $number = 0; ?>
                <?php $__currentLoopData = $rental_show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> 
                <tr>
                    <td>
                        <img src="<?php echo e(URL::asset('ap/assets/img/user_profile.jpg')); ?>" class="img-h-w" alt="" />
                        <b>11-11-11666</b>
                    </td>
                    <td><?php echo e($v->rental_name); ?></td>
                    <td class="text-center"><b><?php echo e($v->bld_name); ?> - <?php echo e($v->bld_floor); ?> - <?php echo e($v->bld_unit); ?></b></td>
                    <td><?php echo e($v->rental_phone_1); ?></td>
                    <td><?php echo e($v->rental_email); ?></td>
                    <td class="text-center"><a href="" class="btn btn-default btn-xs">Paid</a> </td>
                    <td><a href="<?php echo e(URL::to('info-owner-details/'.$v->rental_details_id)); ?>" class="btn btn-default btn-xs"><i class="fa fa-list-alt"></i> Details</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
    </div>
    <!-- end panel -->
</div>
<!-- end section-container -->
<?php $__env->stopSection(); ?>