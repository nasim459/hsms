<!--Page Title-->
<section class="page-title" style="background-image:url(fe/images/background/page-title-bg-1.jpg);">
    <div class="auto-container">
        <div class="content-box">
            <h1>Forums</h1>
            <div class="bread-crumb">
                <a href="{{URL::to('emp_dboard')}}">Home</a> / 
                <a href="{{URL::to('emp_dboard')}}" class="current">Forum</a> /
                <a href="{{URL::to('forum-details')}}" class="current">Forum-Details</a>
            </div>
        </div>
    </div>
</section>