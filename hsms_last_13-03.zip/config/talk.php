<?php

return [
    'user' => [
        'model' => 'App\User',
    ],
    'broadcast' => [
        'enable' => true,
        'app_name' => 'brief-bath-576',
        'pusher' => [
            'app_id' => '300921',
            'app_key' => '29e484002b9114347c47',
            'app_secret' => 'c7cb7d1a1a7c55757437',
        ],
    ],
];

