<?php $__env->startSection('maincontent'); ?>

<h1>Hello YAmin</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('ap.emp_portal.emp_dboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>